import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

const API_URL = (import.meta.env.VITE_API_URL ?? '/api').replace(/\/+$/, '');

export const baseApi = createApi({
  reducerPath: 'api',
  baseQuery: fetchBaseQuery({
    baseUrl: API_URL,
  }),
  tagTypes: ['Dataset', 'Runs'],
  endpoints: () => ({}),
});
